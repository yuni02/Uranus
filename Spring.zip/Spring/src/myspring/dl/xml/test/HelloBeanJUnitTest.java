package myspring.dl.xml.test;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import junit.framework.Assert;
import myspring.dl.xml.Hello;
import myspring.dl.xml.Printer;


import static org.junit.Assert.assertEquals;

public class HelloBeanJUnitTest {
	
	
	ApplicationContext context;
	
	@Before
	public void init() {
		//1.IoC �����̳� ����
		context= new GenericXmlApplicationContext("classpath:config/beans.xml");
	}
	
	@Test
	public void test1() {
		
		//2. Hello Bean ��������
		Hello hello =(Hello) context.getBean("hello");
		assertEquals("Hello Spring",hello.sayHello());
		hello.print();
		//3.String Printer Bean ��������
		Printer printer = context.getBean("printer",Printer.class);
		assertEquals("Hello Spring",printer.toString());
	}
	
	
}
