package myspring.dl.xml.test;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import myspring.dl.xml.Hello;
import myspring.dl.xml.Printer;

public class HelloBeanJUnitSpringTest {
	
	
	ApplicationContext context;
	
	@Before
	public void init() {
		//1.IoC �����̳� ����
		context= new GenericXmlApplicationContext("classpath:beans.xml");
	}
	
	@Test
	public void test1() {
		
		//2. Hello Bean ��������
		Hello hello =(Hello) context.getBean("hello2");
		assertEquals("Hello Spring",hello.sayHello());
		hello.print();
		//3.String Printer Bean ��������
		
		assertEquals(3, hello.getNames().size());
		List<String> list=hello.getNames();
		for(String value: list) {
			System.out.println(value);
		}
		
		Printer printer = context.getBean("printer",Printer.class);
		assertEquals("Hello Spring",printer.toString());
	}
	
	
}
