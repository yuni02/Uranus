package myspring.dl.annot.test;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.Assert.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.GenericApplicationContext;


@RunWith(JUnit4.class) 
@Configuration(locations="classpath:annot.xml")
public class HelloBeanAnnotTest {
	 
	@Autowired
	GenericApplicationContext context;
	
	@Test
	public void test() {
		Hello hello=context.getBean("hello", Hello.class);
		assertEquals("Hello Spring", hello.sayHello());
	}
}
