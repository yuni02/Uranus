package myspring.dl.annot;
public interface Printer {
public void print(String message);
}
