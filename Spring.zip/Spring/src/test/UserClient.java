import java.sql.SQLException;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;

@Configuration(locations="classpath:beans.xml")
public class UserClient {
	@Autowired
	ApplicationContext context;
	
	@Test
	public void dataSourceTest() {
		DataSource ds=context.getBean("dataSource");
		try {
			System.out.println(ds.getConnection());
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Autowired
	UserService service;
	
	public void getUserTest() {
		
		UserVO user =service.getUser("gildong");
		System.out.println(user);
		assertEquals("ȫ�浿", user.getName
	}
}
