package com.codelifee.exercisecoach.exercisecoach.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.codelifee.exercisecoach.exercisecoach.mapper.Exercise_UsersMapper;
import com.codelifee.exercisecoach.exercisecoach.mapper.ExercisesMapper;
import com.codelifee.exercisecoach.exercisecoach.model.Exercise_Users;
import com.codelifee.exercisecoach.exercisecoach.model.Exercises;

@RestController
@RequestMapping("/rest/exercise_users")
@CrossOrigin(origins="http://localhost:5000")
public class Exercise_UsersResource {

	private Exercise_UsersMapper exercise_UsersMapper;
			
	@Autowired
	public Exercise_UsersResource(Exercise_UsersMapper exercise_UsersMapper) {
		this.exercise_UsersMapper = exercise_UsersMapper;
	}

	@GetMapping("/all")
	public List<Exercise_Users> getAll() {
		return exercise_UsersMapper.findAll();
	}
	
	@GetMapping("/{user_id}")
	public Exercise_Users getExercises(@PathVariable("user_id")String user_id) {
		return exercise_UsersMapper.getExercise_Users(user_id);
	}
	
	@PutMapping("/create")
	public void createExercise_Users(@RequestParam("user_id")String user_id, @RequestParam("exer_id")String exer_id, 
			@RequestParam("com_id")int com_id) {
		exercise_UsersMapper.insertExercise_Users(user_id, exer_id, com_id);}
	
	@DeleteMapping("/{user_id}")
	public void deleteExercise_Users(@PathVariable("user_id")String user_id) {
		exercise_UsersMapper.deleteExercise_Users(user_id);
}
}
