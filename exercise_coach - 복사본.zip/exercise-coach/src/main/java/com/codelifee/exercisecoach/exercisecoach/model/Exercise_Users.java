package com.codelifee.exercisecoach.exercisecoach.model;

public class Exercise_Users {

	private String user_id;
	private String exer_id;
	private int com_id;
	
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getExer_id() {
		return exer_id;
	}
	public void setExer_id(String exer_id) {
		this.exer_id = exer_id;
	}
	public int getCom_id() {
		return com_id;
	}
	public void setCom_id(int com_id) {
		this.com_id = com_id;
	}
	
	
}
