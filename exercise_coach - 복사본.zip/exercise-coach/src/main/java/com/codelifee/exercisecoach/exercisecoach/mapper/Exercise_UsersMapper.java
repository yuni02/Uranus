package com.codelifee.exercisecoach.exercisecoach.mapper;



import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.codelifee.exercisecoach.exercisecoach.model.Exercise_Users;

@Mapper
public interface Exercise_UsersMapper {

	@Select("select * from exercise_user order by user_id")
	List<Exercise_Users> findAll();
	
	@Select("SELECT * FROM exercise_user WHERE user_id=#{user_id} order by user_id")
	Exercise_Users getExercise_Users(@Param("user_id")String user_id);
	
	@Insert("INSERT INTO exercise_user VALUES(#{user_id},#{exer_id},#{com_id})")
	int insertExercise_Users(@Param("user_id")String user_id, @Param("exer_id")String exer_id,
			@Param("com_id")int com_ids);
	
	
	@Delete("DELETE FROM exercise_user WHERE user_id=#{user_id}")
	int deleteExercise_Users(@Param("user_id")String exer_id);
	
}
