package com.codelifee.exercisecoach.exercisecoach.model;

public class Exercises {
	
	private String exer_id;
	private String exer_name;
	private String descriptions;
	
	public String getExer_id() {
		return exer_id;
	}
	public void setExer_id(String exer_id) {
		this.exer_id = exer_id;
	}
	public String getExer_name() {
		return exer_name;
	}
	public void setExer_name(String exer_name) {
		this.exer_name = exer_name;
	}
	public String getDescriptions() {
		return descriptions;
	}
	public void setDescriptions(String descriptions) {
		this.descriptions = descriptions;

	
	

}
	
	
}
